//
//  Styles.swift
//  AnimatedApp
//
//  Created by Meng To on 2022-03-30.
//

import SwiftUI
