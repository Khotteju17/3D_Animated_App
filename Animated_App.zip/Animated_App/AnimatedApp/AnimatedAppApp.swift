//
//  AnimatedAppApp.swift
//  AnimatedApp
//
//  Created by Tejashree on 08/03/24.
//

import SwiftUI

@main
struct AnimatedAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .modifier(DarkModeViewModifier())
                    
        }
    }
}
