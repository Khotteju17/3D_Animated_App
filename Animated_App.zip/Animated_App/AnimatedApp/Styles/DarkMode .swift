//
//  DarkMode .swift
//  AnimatedApp
//
//  Created by Tejashree on 20/05/24.
//

import SwiftUI


//class AppThemeViewModel: ObservableObject {
//    
//    @AppStorage("isDarkMode") var isDarkMode: Bool = true                           // also exists in DarkModeViewModifier()
//    //@AppStorage("appTintColor") var appTintColor: AppTintColorOptions = .indigo
//    
//}
//struct DarkModeViewModifier: ViewModifier {
//    @ObservedObject var appThemeViewModel: AppThemeViewModel = AppThemeViewModel()
//    
//    public func body(content: Content) -> some View {
//        content
//            .preferredColorScheme(appThemeViewModel.isDarkMode ? .dark : appThemeViewModel.isDarkMode == false ? .light : nil)
//            .accentColor(.white)
//            //.accentColor(Color($appThemeViewModel.appTintColor.rawValue))
//    }
//}


